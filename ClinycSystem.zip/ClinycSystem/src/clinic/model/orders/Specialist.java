package clinic.model.orders;

public class Specialist {

    private String specialistTypeId;

	public String getSpecialistTypeId() {
		return specialistTypeId;
	}

	public void setSpecialistTypeId(String specialistTypeId) {
		this.specialistTypeId = specialistTypeId;
	}
    
}
