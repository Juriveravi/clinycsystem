package clinic.enums;

public enum Role {
	DOCTOR,
    NURSE,
    ADMIN,
    RH,
    

}
