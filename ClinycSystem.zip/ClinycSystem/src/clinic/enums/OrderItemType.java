package clinic.enums;

public enum OrderItemType {
	 MEDICATION,
	 PROCEDURE,
	 DIAGNOSTIC

}
