package clinic.enums;

public enum Gender {
	MALE,
	FEMALE,
	OTHER

}
